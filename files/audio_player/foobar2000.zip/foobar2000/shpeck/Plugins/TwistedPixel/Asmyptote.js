/*
	Asymptote -- JavaScript implementation
	implemented based on milkdrop version 

	Author:		Unknown
	Adapted:	Brian Spangler
				www.outdoorgrace.com
*/


// Called when the Preset is loaded
function PresetInitialize() 
{
	// set some new preset vars
	tp_fDuration = 20.0 + Math.round(10*Math.random());	// number of seconds to run the preset
	tp_bEnableBeatDetection = 0.0;						// enable/disable internal beatdetection
	tp_nBeatDetectionSensitivity = 192.0;				// establish bBeat sensitivity
	tp_fDesiredFPS = 30.0;								// set FPS for this preset
	tp_NextPreset = "";									// provide path/filename of next preset to load
	// set desired mesh sizes for this preset
	// modes generally used (8,6) (16,12) (24,18) (32,24) (40,30) (48,36) (96,72)
	tp_meshx = 32;
	tp_meshy = 24;

	
	// initialize vars for this preset
	tp_fGammaAdj=2.000000;
	tp_fDecay=0.980000;
	tp_fVideoEchoZoom=2.000000;
	tp_fVideoEchoAlpha=0.000000;
	tp_nVideoEchoOrientation=0;
	tp_nWaveMode=2;
	tp_bAdditiveWaves=1;
	tp_bWaveDots=0;
	tp_bModWaveAlphaByVolume=0;
	tp_bMaximizeWaveColor=1;
	tp_bTexWrap=1;
	tp_bDarkenCenter=0;
	tp_bMotionVectorsOn=0;
	tp_bRedBlueStereo=0;
	tp_nMotionVectorsX=12;
	tp_nMotionVectorsY=9;
	tp_bBrighten=0;
	tp_bDarken=0;
	tp_bSolarize=0;
	tp_bInvert=0;
	tp_fWaveAlpha=6.140000;
	tp_fWaveScale=1.694000;
	tp_fWaveSmoothing=0.900000;
	tp_fWaveParam=0.000000;
	tp_fModWaveAlphaStart=0.750000;
	tp_fModWaveAlphaEnd=0.950000;
	tp_fWarpAnimSpeed=1.000000;
	tp_fWarpScale=1.772000;
	tp_fZoomExponent=0.090000;
	tp_fShader=0.000000;
	tp_zoom=0.971000;
	tp_rot=0.000000;
	tp_cx=0.500000;
	tp_cy=0.500000;
	tp_dx=0.000000;
	tp_dy=0.000000;
	tp_warp=0.513000;
	tp_sx=1.000000;
	tp_sy=1.000000;
	tp_wave_r=0.650000;
	tp_wave_g=0.650000;
	tp_wave_b=0.650000;
	tp_wave_x=0.500000;
	tp_wave_y=0.500000;
	tp_ob_size=0.000000;
	tp_ob_r=0.000000;
	tp_ob_g=0.000000;
	tp_ob_b=0.000000;
	tp_ob_a=0.500000;
	tp_ib_size=0.010000;
	tp_ib_r=0.250000;
	tp_ib_g=0.250000;
	tp_ib_b=0.250000;
	tp_ib_a=0.020000;	
}


// Called per frame
function ProcessPerFrame() 
{
	var fBlah = 0.0;
	var fT = tp_time;

	// update wave color and position
	tp_wave_x += 0.500*( .6 * Math.sin(2.121 * fT) + .4 * Math.sin(1.621*fT) );
	tp_wave_y += 0.500*( .6 * Math.sin(1.742 * fT) + .4 * Math.sin(2.322*fT) );
	tp_wave_r += 0.350*( .6 * Math.sin(0.823 * fT) + .4 * Math.sin(0.916*fT) );
	tp_wave_g += 0.350*( .6 * Math.sin(0.900 * fT) + .4 * Math.sin(1.023*fT) );
	tp_wave_b += 0.350*( .6 * Math.sin(0.808 * fT) + .4 * Math.sin(0.949*fT) );

	// set rotation
	tp_rot += 0.035*( .6 * Math.sin(0.381 * fT) + .4 * Math.sin(0.539 * fT) );
	
	// set center
	tp_cx += 0.030*( .6 * Math.sin(0.374 * fT) + .4 * Math.sin(0.194 * fT) );
	tp_cy += 0.037*( .6 * Math.sin(0.274 * fT) + .4 * Math.sin(0.394 * fT) );
	
	// set inner border
	tp_ib_r += .2 * Math.sin(fT * 0.5413);
	tp_ib_g += .2 * Math.sin(fT * 0.6459);
	tp_ib_b += .2 * Math.sin(fT * 0.4354);	

	fBlah = 3.0/(tp_ib_r + tp_ib_g + tp_ib_b);

	tp_ib_r *= fBlah;
	tp_ib_g *= fBlah;
	tp_ib_b *= fBlah;	
}


// Called when an error has occured in the preset
function PresetException(eCode, eDescription)
{

}


// Called when the preset is unloaded
function PresetTerminate()
{
	// do cleanup
}
